package gui.src;


public interface Informable {
void messageChanged(String message);
}
